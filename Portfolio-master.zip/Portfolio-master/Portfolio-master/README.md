# Portfolio
Web Development Portfolio for CIS 376

Today's Goals
1. Get on GitHub
2. Link codepen.io with GitHub
3. Start a shared class doc (google doc)
  3a. Quiz for Thursday
4. Hello World online
