A Pen created at CodePen.io. You can find this one at https://codepen.io/rebekah5010/pen/bxKaqj.

 Forked from [Hugo Giraudel](http://codepen.io/HugoGiraudel/)'s Pen [Demo Flexbox 1](http://codepen.io/HugoGiraudel/pen/LklCv/).