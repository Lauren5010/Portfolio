A Pen created at CodePen.io. You can find this one at https://codepen.io/rebekah5010/pen/qMPpxz.

 AUTHOR:  Lauren Alford
DATE:  9/6/18
GITHUB:  Lauren5010
CODEPEN:  Lauren5010
This is the starter file to my Web Development Portfolio.