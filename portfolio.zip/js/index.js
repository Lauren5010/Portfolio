x = "Lauren"
console.log("Hi there " + x);